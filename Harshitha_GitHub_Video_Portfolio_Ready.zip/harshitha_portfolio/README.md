# Harshitha S — GitHub Video Portfolio

This is a ready-to-publish, dark-modern portfolio website. It includes a professional portrait, a 30-second MP4 introduction video, resume, education, finance and investment-banking operations knowledge, data analytics skills, project and internship experience, and contact links.

## Publish on GitHub Pages (no software installation required)

1. Sign in at https://github.com/ and create a **Public** repository named `harshitha-portfolio`.
2. Open the repository and choose **Add file → Upload files**.
3. Open this ZIP on your computer and upload the contents of the `harshitha_portfolio` folder (not the outer folder itself). Make sure `index.html`, `styles.css`, `assets/`, and `resume.pdf` appear at the repository root.
4. Click **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then click **Save**.
6. Wait for GitHub Pages to publish. Your site address will be `https://YOUR-GITHUB-USERNAME.github.io/harshitha-portfolio/`.

## Video and photo

The homepage already displays `assets/profile-photo.png` and plays `assets/Harshitha_Portfolio_30s.mp4` directly in the browser. You do not need Canva or YouTube for this version. Keep the file and folder names unchanged.

## Before sharing

Check the email, phone number and LinkedIn link in `index.html`. The site is public, so only share contact details you are comfortable making public.
